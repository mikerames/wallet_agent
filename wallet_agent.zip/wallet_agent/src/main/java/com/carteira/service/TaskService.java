package com.carteira.service;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carteira.dao.ITaskDAO;
import com.carteira.entity.Employee;
import com.carteira.entity.Task;
@Service
public class TaskService implements ITaskService {
	@Autowired
	private ITaskDAO taskDAO;
	@Override
	public Task getTaskById(int taskId) {
		Task obj = taskDAO.getTaskById(taskId);
		return obj;
	}

	@Override
	public List<Task> getAllTasks(){
		return taskDAO.getAllTasks();
	}
	
	@Override
	public synchronized boolean createTask(Task task){
               if (taskDAO.taskExists(task.getTaskname(), task.getIdlayer())) {
    	           return false;
               } else {
    	           taskDAO.createTask(task);
    	           return true;
               }
	}
	@Override
	public void updateTask(Task task) {
		taskDAO.updateTask(task);
	}
	@Override
	public void deleteTask(int taskId) {
		taskDAO.deleteTask(taskId);
	}

	
	
	
	//Delimiters used in the CSV file
	private static final String COMMA_DELIMITER = ",";
	
	public void getCsv() {
		
		// COUNT NUMBER OF LINES
		int result = 0;
		
		try
		(
		   FileReader       input = new FileReader("c:/projects/wallet_agent/Employee.csv");
		   LineNumberReader count = new LineNumberReader(input);	

		)
		{
		   while (count.skip(Long.MAX_VALUE) > 0)
		   {
		      // Loop just in case the file is > Long.MAX_VALUE or skip() decides to not read the entire file
		   }

		   result = count.getLineNumber() + 1;                                    // +1 because line index starts at 0
		}
		catch(Exception ee)
	    {
	        ee.printStackTrace();
	    }
	    finally
	    {
	        System.out.println(result);
	    }
		
				
	//Read from CSV
			//http://www.javainterviewpoint.com/how-to-read-and-parse-csv-file-in-java/
			BufferedReader br = null;
		    try
		    {
		        //Reading the csv file
		        br = new BufferedReader(new FileReader("c:/projects/wallet_agent/Employee.csv"));
		        	        
		        //Create List for holding Employee objects
		        List<Employee> empList = new ArrayList<Employee>();
		        
		        String line = "";
		        //Read to skip the header
		        br.readLine();
		        //Reading from the second line
        	    
		        int x = 1;
		        
		        while ((line = br.readLine()) != null && x <= result - 3) 
		        {
		            String[] employeeDetails = line.split(COMMA_DELIMITER);
           	        
		            System.out.println(x);
		            
		            if(employeeDetails.length > 0)
		            {
		                //Save the employee details in Employee object
		                Employee emp = new Employee(Integer.parseInt(employeeDetails[0]),
		                        employeeDetails[1],employeeDetails[2],
		                        Integer.parseInt(employeeDetails[3]));
		                empList.add(emp);
		            }
		            
		            x = x + 1 ;
		            
		        }
		        
		        //Lets print the Employee List
		        for(Employee e : empList)
		        {
		            System.out.println(e.getEmpId()+"   "+e.getFirstName()+"   "
		            		+e.getLastName()+"   "+e.getSalary());
		        }
		    }
		    catch(Exception ee)
		    {
		        ee.printStackTrace();
		    }
		    finally
		    {
		        try
		        {
		            br.close();
		        }
		        catch(IOException ie)
		        {
		            System.out.println("Error occured while closing the BufferedReader");
		            ie.printStackTrace();
		        }
		    }
	
	}
	
	
	
	
	
	
	
	
} 