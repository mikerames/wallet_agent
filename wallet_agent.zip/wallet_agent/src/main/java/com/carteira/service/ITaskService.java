package com.carteira.service;
import java.util.List;

import com.carteira.entity.Task;

public interface ITaskService {
     List<Task> getAllTasks();
     Task getTaskById(int taskId);
     boolean createTask(Task task);
     void updateTask(Task task);
     void deleteTask(int taskId);
     
     void getCsv();
} 