package com.carteira.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.util.UriComponentsBuilder;

import com.carteira.entity.Task;
import com.carteira.service.ITaskService;



@Controller
@CrossOrigin(origins = {"http://localhost:4200"})
@RequestMapping("/user")
public class TaskController {
	
	@Autowired
	private ITaskService taskService;
		
	@GetMapping("/task")
	public ResponseEntity<Task> getTaskById(@RequestParam("idtask") String id) {
		Task task = taskService.getTaskById(Integer.parseInt(id));
		return new ResponseEntity<Task>(task, HttpStatus.OK);
	}
	
	@PostMapping("/task")
	public ResponseEntity<Void> createTask(@RequestBody Task task, UriComponentsBuilder builder) {
		boolean flag = taskService.createTask(task);
		if (flag == false) {
		     return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(builder.path("/task?id={id}").buildAndExpand(task.getIdtask()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	@PutMapping("/task")
	public ResponseEntity<Task> updateTask(@RequestBody Task task) {
		taskService.updateTask(task);
		return new ResponseEntity<Task>(task, HttpStatus.OK);
	}
	
	@DeleteMapping("/task")
	public ResponseEntity<Void> deleteTask(@RequestParam("id") String id) {
		taskService.deleteTask(Integer.parseInt(id));
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}	
	
	@GetMapping("/all-tasks")
	public ResponseEntity<List<Task>> getAllTasks() {
		List<Task> list = taskService.getAllTasks();
		return new ResponseEntity<List<Task>>(list, HttpStatus.OK);
	}
	
	
	//Test Read CSV
	@GetMapping("/csv")
	public void getCsv() {	
		taskService.getCsv();
	}
	
	
	
	
	
}