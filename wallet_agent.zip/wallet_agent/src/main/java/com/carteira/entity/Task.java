package com.carteira.entity;
import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
@Entity
@Table(name="task")
public class Task implements Serializable { 
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="idtask")
	@JsonProperty("idtask")
    private int idtask;
	
	@Column(name="idproject")	
	@JsonProperty("idproject")
	private int idproject;
	
	@Column(name="taskname")
	@JsonProperty("taskname")
	private String taskname;
	
	@Column(name="assignee_uid")	
	@JsonProperty("assignee_uid")
	private String assignee_uid;
	
	@Column(name="idlayer")	
	@JsonProperty("idlayer")
	private int idlayer;
	
	@Column(name="idtaskstatus")	
	@JsonProperty("idtaskstatus")
	private int idtaskstatus;
	
	@Column(name="comments")	
	@JsonProperty("comments")
	private String comments;
	
	@Column(name="startdate")	
	@JsonProperty("startdate")
	private Date startdate;
	
	@Column(name="enddate")	
	@JsonProperty("enddate")
	private Date enddate;

	//Getter and Setters
	public int getIdtask() {
		return idtask;
	}

	public void setIdtask(int idtask) {
		this.idtask = idtask;
	}

	public int getIdproject() {
		return idproject;
	}

	public void setIdproject(int idproject) {
		this.idproject = idproject;
	}

	public String getTaskname() {
		return taskname;
	}

	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}

	public String getAssignee_uid() {
		return assignee_uid;
	}

	public void setAssignee_uid(String assignee_uid) {
		this.assignee_uid = assignee_uid;
	}

	public int getIdlayer() {
		return idlayer;
	}

	public void setIdlayer(int idlayer) {
		this.idlayer = idlayer;
	}

	public int getIdtaskstatus() {
		return idtaskstatus;
	}

	public void setIdtaskstatus(int idtaskstatus) {
		this.idtaskstatus = idtaskstatus;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

} 