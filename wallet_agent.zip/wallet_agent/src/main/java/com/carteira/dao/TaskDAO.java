package com.carteira.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.carteira.entity.Task;
@Transactional
@Repository
public class TaskDAO implements ITaskDAO {
	@PersistenceContext	
	private EntityManager entityManager;	
	@Override
	public Task getTaskById(int idtask) {
		return entityManager.find(Task.class, idtask);
	}	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Task> getAllTasks() {
		String hql = "FROM Task as atcl ORDER BY atcl.idtask DESC";
		return (List<Task>) entityManager.createQuery(hql).getResultList();
	}
	
	@Override
	public void createTask(Task task) {
		entityManager.persist(task);
	}
	@Override
	public void updateTask(Task task) {
		//TO FIX 
		Task tsk = getTaskById(task.getIdtask());
		tsk.setIdproject(task.getIdproject());
		tsk.setTaskname(task.getTaskname());
		tsk.setAssignee_uid(task.getAssignee_uid());
		tsk.setIdlayer(task.getIdlayer());
		tsk.setIdtaskstatus(task.getIdtaskstatus());
		tsk.setComments(task.getComments());
		tsk.setStartdate(task.getStartdate());
		tsk.setEnddate(task.getEnddate());
		entityManager.flush();
	}
		
	@Override
	public void deleteTask(int taskId) {
		entityManager.remove(getTaskById(taskId));
	}
	@Override
	public boolean taskExists(String taskname, int idtask) {
		String hql = "FROM Task as tsk WHERE tsk.taskname = ? and tsk.idtask = ?";
		int count = entityManager.createQuery(hql).setParameter(1, taskname)
		              .setParameter(2, idtask).getResultList().size();
		return count > 0 ? true : false;
	}
	
}