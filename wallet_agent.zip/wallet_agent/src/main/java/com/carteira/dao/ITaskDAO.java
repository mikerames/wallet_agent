package com.carteira.dao;
import java.util.List;

import com.carteira.entity.Task;
public interface ITaskDAO {
    List<Task> getAllTasks();
    Task getTaskById(int idtask);
    void createTask(Task task);
    void updateTask(Task task);
    void deleteTask(int idtask);
    boolean taskExists(String taskname, int idtask);

    
} 