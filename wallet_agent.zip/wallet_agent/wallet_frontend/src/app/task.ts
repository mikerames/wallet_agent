export class Task {
	constructor(
	public idtask: number,
	public idproject: number,
	public taskname: string,	
	public assignee_uid: string,	
	public idlayer: number,
	public idtaskstatus: number,
	public comments: string,
	public startdate: string,	
	public enddate: string
	) {

	}
}