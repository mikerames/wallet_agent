import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TaskService } from './task.service';
import { Task } from './task';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})

export class TaskComponent implements OnInit {
  //Component properties
  allTasks: Task[];
  statusCode: number;
  requestProcessing = false;
  idTaskToUpdate = null;
  processValidation = false;

  //Create form
  taskForm = new FormGroup({
    idtask: new FormControl('', Validators.required),
    idproject: new FormControl('', Validators.required),
    taskname: new FormControl('', Validators.required),
    idlayer: new FormControl('', Validators.required),
    idtaskstatus: new FormControl('', Validators.required),
    comments: new FormControl('', Validators.required),
    startdate: new FormControl('', Validators.required)
  });

  //Create constructor to get service instance
  constructor(private taskService: TaskService) { }

  //Create ngOnInit() and and load tasks
  ngOnInit(): void {
    this.getAllTasks();
  }

  //Fetch all tasks
  getAllTasks() {
    this.taskService.getAllTasks()
      .subscribe(
      data => this.allTasks = data,
      errorCode => this.statusCode = errorCode);
  }

  //Delete task
  deleteTask(idtask: string) {
    this.taskService.deleteTaskById(idtask)
      .subscribe(successCode => {
        this.statusCode = successCode;
        this.getAllTasks();
      },
      errorCode => this.statusCode = errorCode);
  }

}