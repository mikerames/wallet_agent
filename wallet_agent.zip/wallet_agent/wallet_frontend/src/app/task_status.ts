export class Status {
	constructor(
	public idtaskstatus: number,
	public taskstatus: string
	) {
	}
}