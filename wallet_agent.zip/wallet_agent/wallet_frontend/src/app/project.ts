export class Project {
	constructor(
	public idproject: number,
	public pkey: string,
	public project: string,
	public description: string,
	public active: boolean
	) {
	}
}