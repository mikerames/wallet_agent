import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TaskService } from '../task.service';
import { Task } from '../task';

@Component({
  selector: 'app-onholdtasks',
  templateUrl: './onholdtasks.component.html',
  styleUrls: ['./onholdtasks.component.css']
})
export class OnholdtasksComponent implements OnInit {
  //Component properties
  allOnholdTasks: Task[];
  statusCode: number;
  requestProcessing = false;
  taskIdToUpdate = null;
    
  //Create constructor to get service instance
  constructor(private taskService: TaskService) { }

  ngOnInit(): void {
    this.getOnholdTasks();
  }   

  //Fetch all ongoing tasks
  getOnholdTasks() {
    this.taskService.getOnholdTasks()
  .subscribe(
            data => this.allOnholdTasks = data,
            errorCode =>  this.statusCode = errorCode);   
  }

}

