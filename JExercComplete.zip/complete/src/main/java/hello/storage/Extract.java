package hello.storage;

public class Extract {
	private String dt_mov;
	private String dt_value;
	private String description;
	private String debit;
	private String credit;
	private String bal_account;
	private String bal_avail;
	

	public Extract(
			String dt_mov,
			String dt_value,
			String description,
			String debit,
			String credit,
			String bal_account,
			String bal_avail
			) {
		super();
		this.dt_mov = dt_mov;
		this.dt_value = dt_value;
		this.description = description;
		this.debit = debit;
		this.credit = credit;
		this.bal_account = bal_account;
		this.bal_avail = bal_avail;
	}



	public String getDt_mov() {
		return dt_mov;
	}



	public void setDt_mov(String dt_mov) {
		this.dt_mov = dt_mov;
	}



	public String getDt_value() {
		return dt_value;
	}



	public void setDt_value(String dt_value) {
		this.dt_value = dt_value;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getDebit() {
		return debit;
	}



	public void setDebit(String debit) {
		this.debit = debit;
	}



	public String getCredit() {
		return credit;
	}



	public void setCredit(String credit) {
		this.credit = credit;
	}



	public String getBal_account() {
		return bal_account;
	}



	public void setBal_account(String bal_account) {
		this.bal_account = bal_account;
	}



	public String getBal_avail() {
		return bal_avail;
	}



	public void setBal_avail(String bal_avail) {
		this.bal_avail = bal_avail;
	}



	@Override
	public String toString() {
		return "Extract ["
				+ "dt_mov=" + dt_mov + ", "
				+ "dt_value=" + dt_value + ", "
				+ "description=" + description + ", "
				+ "debit=" + debit + ", "
				+ "credit=" + credit + ", "
				+ "bal_account=" + bal_account + ", "
				+ "bal_avail=" + bal_avail
				+ "]";
	}
}