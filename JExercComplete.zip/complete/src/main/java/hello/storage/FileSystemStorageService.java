package hello.storage;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileSystemStorageService implements StorageService {

	private final Path rootLocation;

	@Autowired
	public FileSystemStorageService(StorageProperties properties) {
		this.rootLocation = Paths.get(properties.getLocation());
	}

	@Override
	public void store(MultipartFile file) {
		String filename = StringUtils.cleanPath(file.getOriginalFilename());
		try {
			if (file.isEmpty()) {
				throw new StorageException("Failed to store empty file " + filename);
			}
			if (filename.contains("..")) {
				// This is a security check
				throw new StorageException(
						"Cannot store file with relative path outside current directory " + filename);
			}
			Files.copy(file.getInputStream(), this.rootLocation.resolve(filename), StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			throw new StorageException("Failed to store file " + filename, e);
		}
	}

	@Override
	public Stream<Path> loadAll() {
		try {
			return Files.walk(this.rootLocation, 1).filter(path -> !path.equals(this.rootLocation))
					.map(path -> this.rootLocation.relativize(path));
		} catch (IOException e) {
			throw new StorageException("Failed to read stored files", e);
		}

	}

	@Override
	public Path load(String filename) {
		return rootLocation.resolve(filename);
	}

	@Override
	public Resource loadAsResource(String filename) {
		try {
			Path file = load(filename);
			Resource resource = new UrlResource(file.toUri());
			if (resource.exists() || resource.isReadable()) {
				return resource;
			} else {
				throw new StorageFileNotFoundException("Could not read file: " + filename);

			}
		} catch (MalformedURLException e) {
			throw new StorageFileNotFoundException("Could not read file: " + filename, e);
		}
	}

	@Override
	public void deleteAll() {
		FileSystemUtils.deleteRecursively(rootLocation.toFile());
	}

	@Override
	public void init() {
		try {
			Files.createDirectories(rootLocation);
		} catch (IOException e) {
			throw new StorageException("Could not initialize storage", e);
		}
	}

	////////////////
	// File to Read//
	////////////////

	// Delimiters used in the CSV file
	private static final String COMMA_DELIMITER = ";";

	@Override
	public void readAFile(MultipartFile file) {

		BufferedReader br = null;
		try {

			// Adds Input file to root folder
			File convFile = new File(file.getOriginalFilename());
			convFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(convFile);
			fos.write(file.getBytes());

			System.out.println(convFile);

			fos.close();
			//

			// Calls the line counting method
			// int z = count("c:/temp/comprovativo.csv");
			// int z = count(path);

			// System.out.println("Shit: " + z);

			// Reading the csv file
			br = new BufferedReader(new FileReader(convFile.getName()));

			// Create List for holding Extract objects
			List<Extract> empList = new ArrayList<Extract>();

			String line = "";

			// Read to skip the header having 6 lines
			for (int x = 0; x <= 6; ++x) {
				br.readLine();
			}

			// Reading from the second line
			while ((line = br.readLine()) != null) {
				String[] ExtractDetails = line.split(COMMA_DELIMITER);

				if (ExtractDetails.length > 0) {
					// Save the Extract details in Extract object
					Extract emp = new Extract(ExtractDetails[0], ExtractDetails[1], ExtractDetails[2],
							ExtractDetails[3], ExtractDetails[4], ExtractDetails[5], ExtractDetails[6]);
					empList.add(emp);
				}
			}

			// Lets print the Extract List
			for (Extract e : empList) {
				System.out.println(e.getDt_mov() + "   " + e.getDt_value() + "   " + e.getDescription() + "   "
						+ e.getDebit() + "   " + e.getCredit() + "   " + e.getBal_account() + "   " + e.getBal_avail());
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException ie) {
				System.out.println("Error occured while closing the BufferedReader");
				ie.printStackTrace();
			}
		}
	}

	// Counts number of lines
	public static int count(String filename) throws IOException {
		InputStream is = new BufferedInputStream(new FileInputStream(filename));
		try {
			byte[] c = new byte[1024];
			int count = 0;
			int readChars = 0;
			boolean empty = true;
			while ((readChars = is.read(c)) != -1) {
				empty = false;
				for (int i = 0; i < readChars; ++i) {
					if (c[i] == '\n') {
						++count;
					}
				}
			}
			return (count == 0 && !empty) ? 1 : count;
		} finally {
			is.close();
		}
	}

}
